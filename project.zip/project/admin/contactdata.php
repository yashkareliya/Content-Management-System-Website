<?php
// insert.php

// 1. Connect to the database
$host = "localhost";
$username = "root"; // change this if needed
$password = "";     // change this if needed
$database = "ksv";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];
$subject=$_POST['subject'];
$message=$_POST['message'];

// 3. Prepare and bind
$stmt = $conn->prepare("INSERT INTO enquiry (name, email, mobile, subject, message) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssiss", $name, $email, $number, $subject, $message);



// 4. Execute
if ($stmt->execute()) {
    echo "New record inserted successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// 5. Close
$stmt->close();
$conn->close();
?>

