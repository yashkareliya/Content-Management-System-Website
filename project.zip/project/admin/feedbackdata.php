<?php
include('includes/connection.php');
include('includes/allfunction.php');


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>All Enquiry</title>
   
   <?php include_once('includes/css.php'); ?>
   
  </head>
  <body>
    <div class="container-scroller">

   
   <?php include_once('includes/header.php'); ?>
   
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
       
	   <?php include_once('includes/sidebar.php'); ?>
	   
            </div>
            
            
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Feedback</h4>
                 
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Sr.No</th>
                          
                          <th>Name</th>
                          <th>email</th>
                          <th>mobile</th>
						  
						  <th>message</th>
						  
                        </tr>
                      </thead>
                      <tbody>
                        <?php
					  $servicesdata=fetchalldata('feedback');
					  $i=1;
					  while($data=mysqli_fetch_array($servicesdata))
					  {?>
                        <tr>
                          <td><?php echo $i; ?></td>
                          <td><?php echo $data['name'];?></td>
                          <td><?php echo $data['email'];?></td>
                          <td><?php echo $data['mobile'];?></td>
                          <td><?php echo $data['feedback'];?></td>
                          </tr>                      
					  <?php $i++; } ?>
                       
                      </tbody>
                    </table>
					
                  </div>
                </div>
              </div>
            
            
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
				
		<?php include_once('includes/footer.php'); ?>		
				
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
   
   <?php include_once('includes/script.php'); ?>
   
  </body>
</html>